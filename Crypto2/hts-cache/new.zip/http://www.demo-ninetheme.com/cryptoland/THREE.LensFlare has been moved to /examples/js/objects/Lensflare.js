<!DOCTYPE html><html
lang="en-US" class="no-js" ><head><link
rel="stylesheet" type="text/css" href="http://www.demo-ninetheme.com/cryptoland/wp-content/cache/minify/8ac6f.css" media="all" /><meta
charset="UTF-8"><meta
http-equiv="X-UA-Compatible" content="IE=edge"><meta
name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"><meta
name="theme-color" content="#000"><title>Page not found &#8211; Crypytoland</title><link
rel='dns-prefetch' href='//fonts.googleapis.com' /><link
rel='dns-prefetch' href='//s.w.org' /><link
rel="alternate" type="application/rss+xml" title="Crypytoland &raquo; Feed" href="http://www.demo-ninetheme.com/cryptoland/feed/" /><link
rel="alternate" type="application/rss+xml" title="Crypytoland &raquo; Comments Feed" href="http://www.demo-ninetheme.com/cryptoland/comments/feed/" /> <script type="text/javascript">/*<![CDATA[*/window._wpemojiSettings={"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/www.demo-ninetheme.com\/cryptoland\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.9.8"}};!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55358,56760,9792,65039],[55358,56760,8203,9792,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);/*]]>*/</script> <style type="text/css">img.wp-smiley,img.emoji{display:inline !important;border:none !important;box-shadow:none !important;height:1em !important;width:1em !important;margin:0
.07em !important;vertical-align:-0.1em !important;background:none !important;padding:0
!important}</style><style id='cryptoland-custom-style-inline-css' type='text/css'>div#preloader{background-color:#fff;overflow:hidden;background-repeat:no-repeat;background-position:center center;height:100%;left:0;position:fixed;top:0;width:100%;z-index:10000}.loader05{width:56px;height:56px;border:4px
solid #00d8d6;border-radius:50%;position:relative;animation:loader-scale 1s ease-out infinite;top:50%;margin:-28px auto 0}@keyframes loader-scale{0%{transform:scale(0);opacity:0}50%{opacity:1}100%{transform:scale(1);opacity:0}}p{margin-top:0;margin-bottom:20px}p:last-child{margin-bottom:0}p{margin:10px
0 15px}img{max-width:100%}.c-backtop-1{line-height:50px!important}.c-backtop-1 i:before{font-size:17px!important}.c-backtop-1
i{bottom:50px!important}.c-backtop-1{background-color:#8761a8;background-image:-webkit-gradient(linear,left top,right top,from(#8761a8),to(#f4929b));background-image:-webkit-linear-gradient(left,#8761a8 0,#f4929b 100%);background-image:-o-linear-gradient(left,#8761a8 0,#f4929b 100%);background-image:linear-gradient(to right,#8761a8 0,#f4929b 100%)}.nt-img-lg_d
img{width:45px !important}.nt-img-logo
img{height:51px !important}@media (max-width: 1200px){.fixed-menu .fixed-menu__content,.mob-menu__item{text-align:left!important}}.page-id-.hero-fullwidth{background-image:url(http://www.demo-ninetheme.com/cryptoland/wp-content/themes/cryptoland/framework/images/main_bg.png)}.page-id-.hero-fullwidth{height:55vh !important;max-height:100%}@media (max-width: 767px){.page-id-.hero-fullwidth{max-height:60vh !important}}.page-id-.hero-fullwidth .hero-content{text-align:center!important}.page-id-.hero-fullwidth{}.page-id-.hero-fullwidth{}.footer-widget-area{}.footer-widget-area{padding-top:96px !important}.copyright{padding-top:44px !important;padding-bottom:65px !important}.copyright{}</style><link
rel='stylesheet' id='cryptoland-fonts-css'  href='//fonts.googleapis.com/css?family=Catamaran%3A300%2C400%2C600%2C700%7CRaleway%3A100%2C700%7CRoboto%3A700&#038;subset=latin%2Clatin-ext&#038;ver=1.0' type='text/css' media='all' /> <script type="text/javascript" src="http://www.demo-ninetheme.com/cryptoland/wp-content/cache/minify/3e8fc.js"></script> <!--[if lt IE 9]> <script type='text/javascript' src='http://www.demo-ninetheme.com/cryptoland/wp-content/themes/cryptoland/framework/js/modernizr.min.js'></script> <![endif]-->
<!--[if lt IE 9]> <script type='text/javascript' src='http://www.demo-ninetheme.com/cryptoland/wp-content/themes/cryptoland/framework/js/respond.min.js'></script> <![endif]-->
<!--[if lt IE 9]> <script type='text/javascript' src='http://www.demo-ninetheme.com/cryptoland/wp-content/themes/cryptoland/js/html5shiv.min.js'></script> <![endif]--><link
rel='https://api.w.org/' href='http://www.demo-ninetheme.com/cryptoland/wp-json/' /><link
rel="EditURI" type="application/rsd+xml" title="RSD" href="http://www.demo-ninetheme.com/cryptoland/xmlrpc.php?rsd" /><link
rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://www.demo-ninetheme.com/cryptoland/wp-includes/wlwmanifest.xml" /><meta
name="generator" content="WordPress 4.9.8" /><style type="text/css">.recentcomments
a{display:inline !important;padding:0
!important;margin:0
!important}</style><meta
name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>
<!--[if lte IE 9]><link
rel="stylesheet" type="text/css" href="http://www.demo-ninetheme.com/cryptoland/wp-content/plugins/visual_composer/assets/css/vc_lte_ie9.min.css" media="screen"><![endif]--><link
rel="icon" href="http://www.demo-ninetheme.com/cryptoland/wp-content/uploads/2018/10/cropped-graphic-32x32.png" sizes="32x32" /><link
rel="icon" href="http://www.demo-ninetheme.com/cryptoland/wp-content/uploads/2018/10/cropped-graphic-192x192.png" sizes="192x192" /><link
rel="apple-touch-icon-precomposed" href="http://www.demo-ninetheme.com/cryptoland/wp-content/uploads/2018/10/cropped-graphic-180x180.png" /><meta
name="msapplication-TileImage" content="http://www.demo-ninetheme.com/cryptoland/wp-content/uploads/2018/10/cropped-graphic-270x270.png" /><style type="text/css" id="wp-custom-css">@media (max-width:768px){.wpb-js-composer .vc_general.vc_tta.vc_tta-accordion.vc_tta-color-cryptoland_vc_tta-color-purple .vc_tta-panel-title>a:before{right:8.5px}.chart__wrap{position:relative;margin-bottom:60px}.token__info-list{margin-bottom:60px}img.platform__img{margin-top:41px}.vc_custom_1538511914519{text-align:center !important}.press-carousel .owl-dots{margin-top:65px}.wpb_single_image.vc_align_left{text-align:center}.home3 .scroll-down{bottom:-70px}.wpb-js-composer .vc_general.vc_tta.vc_tta-accordion.vc_tta-color-cryptoland_vc_tta-color-transparent .vc_tta-panel-title>a:before{right:7px}body #hero.hero-fullwidth{padding:63% 15px 42%;max-height:100% !important}.c-sidebar-1-widget{margin-bottom:60px;padding:0px
!important}}@media (max-width:575px){.c-blog-3-info{padding:10px
0}.c-sidebar-1-widget{margin-bottom:60px;padding:0px
!important}}#hero.first-screen
p.breadcrumb{font-size:16px;font-weight:700;color:#fff}.breadcrumb
a{color:#fff;margin:0
3px}.flexslider .slides > li:before, .flex-direction-nav li:before, .flexslider ul li:before{width:0px}.flexslider .flex-direction-nav
li{position:inherit}#gallery-1 .gallery-item{float:left;margin-top:0px;text-align:center;width:33%}.c-sidebar-1-widget ol li, .c-sidebar-1-widget ul
li{text-transform:capitalize}ul#recentcomments li
span{color:#895faa;font-weight:600}</style><noscript><style type="text/css">.wpb_animate_when_almost_visible{opacity:1}</style></noscript></head><body
class="error404 nt-shortcode-1.0 Ninetheme-Cryptoland Ninetheme-Version-1.0 body-inner-class wpb-js-composer js-comp-ver-5.5.1 vc_responsive"><div
id="preloader" class="preloader"><div
class="loader05"></div></div>
<header
class="header sticky-on">
<a
class="logo nt-logo" href="http://www.demo-ninetheme.com/cryptoland/"><div
class="logo__img bg-none nt-img-logo">
<img
class="static-logo" src="http://www.demo-ninetheme.com/cryptoland/wp-content/uploads/2018/09/Logo_white.svg" width="45" height="51" alt="Logo">
<img
class="sticky-logo" src="http://www.demo-ninetheme.com/cryptoland/wp-content/uploads/2018/09/Logo_gradient.svg" width="45" height="51" alt="Logo"></div><div
class="logo__title nt-text-logo">Cryptoland</div>
</a><div
class="menu-primary-container"><ul
id="menu-primary" class="menu"><li
id="menu-item-7" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu__item menu-item-7"><a
class="menu__link"  title="About" href="http://www.demo-ninetheme.com/cryptoland/#about">About</a></li><li
id="menu-item-10" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu__item menu-item-10"><a
class="menu__link"  title="Services" href="http://www.demo-ninetheme.com/cryptoland/#services">Services</a></li><li
id="menu-item-31" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu__item menu-item-31"><a
class="menu__link"  title="Road Map" href="http://www.demo-ninetheme.com/cryptoland/#timeline">Road Map</a></li><li
id="menu-item-32" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu__item menu-item-32"><a
class="menu__link"  title="Statistic" href="http://www.demo-ninetheme.com/cryptoland/#statistic">Statistic</a></li><li
id="menu-item-33" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu__item menu-item-33"><a
class="menu__link"  title="Token" href="http://www.demo-ninetheme.com/cryptoland/#token">Token</a></li><li
id="menu-item-35" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu__item menu-item-35"><a
class="menu__link"  title="Team" href="http://www.demo-ninetheme.com/cryptoland/#team">Team</a></li><li
id="menu-item-842" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu__item menu-item-842"><a
class="menu__link"  title="Contact" href="http://www.demo-ninetheme.com/cryptoland/#contact">Contact</a></li></ul></div><div
class="header__right">
<select
class="select"><option
value="RU">RU</option><option
value="UA">UA</option><option
value="EN">EN</option>
</select><div
class="sign-in-wrap"><a
href="#0" class="btn-sign-in">Sign in</a></div><div
class="sign-up-wrap"><a
href="#0" class="btn-sign-up">Sign up</a></div></div><div
class="btn-menu"><div
class="one"></div><div
class="two"></div><div
class="three"></div></div>
</header><div
class="fixed-menu"><div
class="fixed-menu__header">
<a
class="logo logo--color mob-sticky-text-logo nt-logo" href="http://www.demo-ninetheme.com/cryptoland/"><div
class="logo__img bg-none nt-img-logo">
<img
class="static-logo" src="http://www.demo-ninetheme.com/cryptoland/wp-content/uploads/2018/09/Logo_white.svg" width="45" height="51" alt="Logo">
<img
class="sticky-logo" src="http://www.demo-ninetheme.com/cryptoland/wp-content/uploads/2018/09/Logo_gradient.svg" width="45" height="51" alt="Logo"></div><div
class="logo__title nt-text-logo">Cryptoland</div>
</a><div
class="btn-close">
<svg
xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewBox="0 0 47.971 47.971" style="enable-background:new 0 0 47.971 47.971;" xml:space="preserve" width="512px" height="512px">
<path
d="M28.228,23.986L47.092,5.122c1.172-1.171,1.172-3.071,0-4.242c-1.172-1.172-3.07-1.172-4.242,0L23.986,19.744L5.121,0.88   c-1.172-1.172-3.07-1.172-4.242,0c-1.172,1.171-1.172,3.071,0,4.242l18.865,18.864L0.879,42.85c-1.172,1.171-1.172,3.071,0,4.242   C1.465,47.677,2.233,47.97,3,47.97s1.535-0.293,2.121-0.879l18.865-18.864L42.85,47.091c0.586,0.586,1.354,0.879,2.121,0.879   s1.535-0.293,2.121-0.879c1.172-1.171,1.172-3.071,0-4.242L28.228,23.986z" fill="#006DF0"/></svg></div></div><div
class="fixed-menu__content"><div
class="menu-primary-container"><ul
id="menu-primary-1" class="mob-menu"><li
class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home mob-menu__item menu-item-7"><a
class="mob-menu__link"  title="About" href="http://www.demo-ninetheme.com/cryptoland/#about">About</a></li><li
class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home mob-menu__item menu-item-10"><a
class="mob-menu__link"  title="Services" href="http://www.demo-ninetheme.com/cryptoland/#services">Services</a></li><li
class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home mob-menu__item menu-item-31"><a
class="mob-menu__link"  title="Road Map" href="http://www.demo-ninetheme.com/cryptoland/#timeline">Road Map</a></li><li
class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home mob-menu__item menu-item-32"><a
class="mob-menu__link"  title="Statistic" href="http://www.demo-ninetheme.com/cryptoland/#statistic">Statistic</a></li><li
class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home mob-menu__item menu-item-33"><a
class="mob-menu__link"  title="Token" href="http://www.demo-ninetheme.com/cryptoland/#token">Token</a></li><li
class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home mob-menu__item menu-item-35"><a
class="mob-menu__link"  title="Team" href="http://www.demo-ninetheme.com/cryptoland/#team">Team</a></li><li
class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home mob-menu__item menu-item-842"><a
class="mob-menu__link"  title="Contact" href="http://www.demo-ninetheme.com/cryptoland/#contact">Contact</a></li></ul></div>
<select
class="select mob-on"><option
value="RU">RU</option><option
value="UA">UA</option><option
value="EN">EN</option>
</select><div
class="btn-wrap mob-on">
<a
href="#0" class="btn-sign-in">Sign in</a>
<a
href="#0" class="btn-sign-up">Sign up</a></div></div></div><div
class="c-backtop-1 -js-backtop">
<i
class="c-backtop-1-icon fa fa-angle-up"></i></div><div
class="wrapper"><div
id="cryptoland-404" class="cryptoland-404"><div
id="hero" class="first-screen page-id- hero-fullwidth nt-inner-pages-hero"  ><div
class="hero-content text-center"><div
class="grid container"><div
class="row row-xs-middle"><div
class="hero-innner-last-child"><h1 class="u-text-hero">404 - Not Found.</h1><p
class="breadcrumb">
<span
property="itemListElement" typeof="ListItem"><a
property="item" typeof="WebPage" title="Go to Crypytoland." href="http://www.demo-ninetheme.com/cryptoland" class="home"><span
property="name">Crypytoland</span></a><meta
property="position" content="1"></span> &gt; <span
class="404 current-item">404</span></p></div></div></div></div></div><div
id="error-page-container" class="bg-white c-section -space-large"><div
class="grid container"><div
class="row row-xs-middle"><div
class="full-width-index col-md-10 offset-2 col-lg-8 content-error text-center"><h3 class="black">Hmm, we could not find what you are looking for.</h3><p>It looks like nothing was found at this location. Maybe try a search?</p><div
class="search-form-page-container"><div
class="c-sidebar-1-search"><form
class="c-sidebar-1-search-form" role="search" method="get" id="searchform" action="http://www.demo-ninetheme.com/cryptoland/" >
<input
class="c-sidebar-1-search-field" type="text" value="" placeholder="Search for..." name="s" id="s" >
<button
class="c-sidebar-1-search-button" id="searchsubmit" type="submit"><i
class="fa fa-search" aria-hidden="true"></i></button></form></div></div></div></div></div></div></div></div>
<footer
class="footer footer-widget-area"><div
class="container"><div
class="row"><div
class="widget_text col-sm-10 col-md-8 col-lg-6"><div
class="widget_text widget widget_custom_html"><div
class="textwidget custom-html-widget"><div
class="footer__block">
<a
href="" class="logo">
<img
class="logo__img--big" src="http://www.demo-ninetheme.com/cryptoland/wp-content/uploads/2018/09/Logo_gradient.svg" alt="">
</a><div
class="footer__text"><p>523 Sylvan Ave, 5th Floor Mountain View, CA</p><p>+1 (234) 56789, +1 987 654 3210</p><p>info@cryptoland.com</p><p>supportcenter@cryptoland.com</p></div></div></div></div></div><div
class="widget_text col-sm-10 col-md-8 col-lg-3"><div
class="widget_text widget widget_custom_html"><div
class="textwidget custom-html-widget"><ul
class="footer-menu"><li
class="footer-menu__item">
<a
href="" class="footer-menu__link">About</a></li><li
class="footer-menu__item">
<a
href="" class="footer-menu__link">Services</a></li><li
class="footer-menu__item">
<a
href="" class="footer-menu__link">Road Map</a></li><li
class="footer-menu__item">
<a
href="" class="footer-menu__link">Statistic</a></li><li
class="footer-menu__item">
<a
href="" class="footer-menu__link">Token</a></li><li
class="footer-menu__item">
<a
href="" class="footer-menu__link">WhitePappers</a></li><li
class="footer-menu__item">
<a
href="" class="footer-menu__link">Team</a></li><li
class="footer-menu__item">
<a
href="" class="footer-menu__link">FAQ</a></li></ul></div></div></div><div
class="widget_text col-sm-10 col-md-4 col-lg-3"><div
class="widget_text widget widget_custom_html"><div
class="textwidget custom-html-widget"><ul
class="footer__list"><li
class="footer__list-item">Whitepaper</li><li
class="footer__list-item">Technical Paper</li><li
class="footer__list-item">Business Summary</li><li
class="footer__list-item">Brand Resources</li></ul></div></div></div></div></div>
</footer><div
class="copyright pt-45"><div
class="container"><div
class="row"><div
class="col"><p>2018, Cryptoland Theme by Artureanec - Ninetheme</p></div></div></div></div> <script type='text/javascript'>var wpcf7={"apiSettings":{"root":"http:\/\/www.demo-ninetheme.com\/cryptoland\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"},"recaptcha":{"messages":{"empty":"Please verify that you are not a robot."}},"cached":"1"};</script> <script type="text/javascript" src="http://www.demo-ninetheme.com/cryptoland/wp-content/cache/minify/e6bac.js"></script> </body></html>